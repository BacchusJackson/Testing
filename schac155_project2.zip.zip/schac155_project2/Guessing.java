public class Guessing {
  public static void main(String[] args){

      System.out.println("Hello, think of a number and I'll try to guess it.");//opening prompt for the user
      int min = lowBound();//set these to functions at the bottom, similar to the randomInt
      int max = highBound();

      while(min > max) {
      System.out.println("Sorry second number needs to be larger than your lower number. Try again.");
      min = lowBound();
      max = highBound();
      }//end of the first while loop. I'm making sure the user doesn't input a smaller number than the lower bound

      //System.out.println(low);//I used these for debugging my functions
      //System.out.println(high);//I used these for debugging my functions

      int computerGuess = randomInt(min, max);//program's random number

      System.out.printf("Is %d your number? You can type (1) for yes or (2) for no.", randomInt(min, max));//first guess at the user's number
      int response = TextIO.getInt();//waiting for the user to respond either 1 or 2 and making sure it's a integer

      while (response > 2) {
          response = yesNo();//this function is also at the bottom and this is to make sure the user either inputs 1 or 2. If not, the program will keep prompting the user to select yes or no
        if (response == 1) {
          System.out.println("I got it! Thanks for playing!");//the program was very lucky and guessed your number on the first try!
        }
      }//end of while loop for the answer yes

      while (response == 2) {//if the user says no (2), the next while loop will run
          System.out.println("Well is your number greater or less than my guess? Please type (3) for greater than or (4) for less than:");
			    response = TextIO.getInt();
        if (response > 4 || response < 3) {
        response = greaterLess();//this if statement and it's function is to ensure the user only selects 3 or 4. If not, the program will keep asking
      }
        if (response == 3) {
          computerGuess = randomInt(computerGuess, max);//This is where I get hung up. I am trying to tell the program to use the randomInt as the new low bound. I can't figure out how to correct this.
          //System.out.println(computerGuess); I used this to try and debug my problem. I just ran out of time and I can't seem to figure out what's wrong.
        }
          else if (response == 4) {
          computerGuess = randomInt(min, computerGuess);//Samething as the low bound, I can't figure out how to correct so my program will use the new number as the high bound.
          }
    	    System.out.printf("... What about %d? Please type (1) for yes or (2) for no.", randomInt(min, max));
            response = TextIO.getInt();
      }//while loop for if the user answsers "no"

      System.out.println("I got it! Thanks for playing!");

  }//main

    public static int greaterLess() {//function for the greater than and less than loop
      System.out.println("Sorry, please enter 3 or 4");
      int userInput = TextIO.getInt();

      return userInput;
    }

    public static int yesNo() {//function for the yes and no loop
      System.out.println("Sorry, please enter 1 or 2");
      int userInput = TextIO.getInt();

      return userInput;
    }

    public static int lowBound() {//function for the lowest Number
      System.out.print("First, what is the lowest your number could be: ");
      int userInput = TextIO.getInt();

    	return userInput;
    }

    public static int highBound() {//function for the highest Number
      System.out.print("Neat, what is the highest your number could be: ");
      int userInput = TextIO.getInt();

      return userInput;
    }

  	public static int randomInt(int min, int max) {//function for the random number
  		return (int)((Math.random()*((max-min)+1))+min);
  	}
}//Guessing program
